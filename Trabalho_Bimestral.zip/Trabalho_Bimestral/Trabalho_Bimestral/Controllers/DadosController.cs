﻿using Microsoft.AspNetCore.Mvc;
using Trabalho_Bimestral.Context;

namespace Trabalho_Bimestral.Controllers
{
    public class DadosController : Controller
    {
        private readonly AppCont _appCont;


        public DadosController(AppCont appCont)
        {
            _appCont = appCont;

        }

        public IActionResult Index()
        {
            var allTasks = _appCont.InfoClientes.ToList();
            return View(allTasks);
        }
    }
}
