﻿using Trabalho_Bimestral.Models;

namespace Trabalho_Bimestral.Context
{
    public static class DBInitializer
    {
        public static void Seed(WebApplication app)
        {
            using (var serviceScope = app.Services.CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetRequiredService<AppCont>();

                context.Database.EnsureCreated();

                // Verifica se já existem clientes no banco
                if (!context.InfoClientes.Any())
                {
                    // Adiciona uma lista de clientes e seus endereços
                    context.InfoClientes.AddRange(new List<Dados>
                    {
                        new Dados
                        {
                            Nome = "Bianca",
                            Email = "binbin123@gmail.com",
                            Rua = "Avenida da paz",
                            Numero = 157,
                            Cidade = "Ribeirão Preto",
                            Estado = "SP",
                            Pais = "Brasil"
},

                        new Dados
                        {
                            Nome = "Maria Eduarda",
                            Email = "dudsmacetinho@gmail.com",
                            Rua = "Rua das ervas",
                            Numero = 169,
                            Cidade = "São Paulo",
                            Estado = "SP",
                            Pais = "Brasil"
                        },

                        new Dados
                        {
                            Nome = "Davi",
                            Email = "davialmeida@gmail.com",
                            Rua = "Avenida das rosas",
                            Numero = 855,
                            Cidade = "Guariba",
                            Estado = "SP",
                            Pais = "Brasil"
                        },

                        new Dados
                        {
                            Nome = "Caio",
                            Email = "murakinha@gmail.com",
                            Rua = "Rua cohab2",
                            Numero = 274,
                            Cidade = "Jaboticabal",
                            Estado = "SP",
                            Pais = "Brasil"
                        },

                        new Dados
                        {
                            Nome = "Thiago",
                            Email = "thiago.quatroque@gmail.com",
                            Rua = "Avenida dos burguer",
                            Numero = 356,
                            Cidade = "Sertãozinho",
                            Estado = "SP",
                            Pais = "Brasil"
                        }
                    });

                    // Salva as mudanças no banco de dados
                    context.SaveChanges();
                }
            }
        }
    }
}

