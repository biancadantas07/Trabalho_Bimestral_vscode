﻿using Trabalho_Bimestral.Models;
using Microsoft.EntityFrameworkCore;

namespace Trabalho_Bimestral.Context
{
    public class AppCont : DbContext
    {

            public AppCont(DbContextOptions<AppCont> options) : base(options)
            {

            }

            public DbSet<Dados> InfoClientes { get; set; }

        }
    }
